#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "config.h"

// ── Estado da vaga ────────────────────────────────────────────────────────────
enum class SpotState { UNKNOWN, OCCUPIED, FREE };

static SpotState currentState   = SpotState::UNKNOWN;
static SpotState lastPublished  = SpotState::UNKNOWN;

// ── Sessão ────────────────────────────────────────────────────────────────────
static char currentSessionCode[7] = ""; // 6 dígitos + nulo
static unsigned long sessionCodeGeneratedMs = 0;
#define SESSION_CODE_TTL_MS (5 * 60 * 1000UL) // 5 minutos

// ── Informações da Sessão Ativa ──────────────────────────────────────────────
static long remainingMinutes = 0;
static char vehicleModel[30] = "";
static char vehiclePlate[15] = "";
static char vehicleColor[20] = "";
static unsigned long lastInfoReceivedMs = 0;

// Marca o momento em que a vaga ficou continuamente vazia
static unsigned long freeStartMs = 0;
static bool         freeTimerRunning = false;

// ── Timestamps não-bloqueantes ────────────────────────────────────────────────
static unsigned long lastSensorReadMs  = 0;
static unsigned long lastConnCheckMs   = 0;
static unsigned long lastPublishMs     = 0;
static unsigned long lastOledUpdateMs  = 0;
static unsigned long lastHeartbeatMs   = 0;

#define HEARTBEAT_INTERVAL_MS (60 * 1000UL) // Heartbeat a cada 1 minuto para não sobrecarregar

// ── Clientes ─────────────────────────────────────────────────────────────────
WiFiClient   wifiClient;
PubSubClient mqttClient(wifiClient);

// ── OLED ─────────────────────────────────────────────────────────────────────
Adafruit_SSD1306 oled(OLED_WIDTH, OLED_HEIGHT, &Wire, -1);
static bool oledOk = false;

// ── Tópico MQTT ──────────────────────────────────────────────────────────────
static char mqttTopic[80];
static char mqttClientId[40];

// ─────────────────────────────────────────────────────────────────────────────
// Variáveis Globais de Estado
// ─────────────────────────────────────────────────────────────────────────────
static char lastPublishedPayload[40] = "";

// ─────────────────────────────────────────────────────────────────────────────
// Protótipos
// ─────────────────────────────────────────────────────────────────────────────
void setupOled();
void setupWifi();
void setupMqtt();
void ensureWifi();
void ensureMqtt();
long readDistanceCm();
void processDistance(long cm);
void publishState(SpotState state, bool force = false);
void updateOled(long cm);
void mqttCallback(char* topic, byte* payload, unsigned int length);

// ─────────────────────────────────────────────────────────────────────────────
// Setup
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    Serial.printf("\n[PontoLivre] FW %s  Meter: %s\n", FW_VERSION, METER_ID);

    // Inicializar semente randomica
    randomSeed(analogRead(0) + ESP.getCycleCount());

    // HC-SR04
    pinMode(HCSR04_TRIG_PIN, OUTPUT);
    pinMode(HCSR04_ECHO_PIN, INPUT);
    digitalWrite(HCSR04_TRIG_PIN, LOW);

    // OLED
    Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);
    setupOled();

    // Tópico + client ID
    snprintf(mqttTopic,    sizeof(mqttTopic),    "parquimetro/%s/status", METER_ID);
    snprintf(mqttClientId, sizeof(mqttClientId), "esp32-%s", METER_ID);

    // WiFi + MQTT
    setupWifi();
    setupMqtt();
}

// ─────────────────────────────────────────────────────────────────────────────
// Loop — sem delay(), sem blocking
// ─────────────────────────────────────────────────────────────────────────────
void loop() {
    unsigned long now = millis();

    // 1. Garantir conectividade
    if (now - lastConnCheckMs >= CONN_CHECK_INTERVAL_MS) {
        lastConnCheckMs = now;
        ensureWifi();
        ensureMqtt();
    }

    // 2. Processar loop MQTT (manter keep-alive e receber mensagens)
    mqttClient.loop();

    // 3. Leitura do sensor
    if (now - lastSensorReadMs >= SENSOR_READ_INTERVAL_MS) {
        lastSensorReadMs = now;
        long cm = readDistanceCm();
        processDistance(cm);

        // Atualizar OLED a cada 500ms (não a cada leitura, para reduzir flickering)
        if (now - lastOledUpdateMs >= 500) {
            lastOledUpdateMs = now;
            updateOled(cm);
        }
    }

    // 4. Envio periódico de status (Heartbeat para manter o backend atualizado)
    if (now - lastHeartbeatMs >= HEARTBEAT_INTERVAL_MS) {
        lastHeartbeatMs = now;
        // No heartbeat, apenas garantimos que o backend saiba o estado atual sem forçar troca
        if (currentState != SpotState::UNKNOWN) {
            publishState(currentState, false);
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// WiFi
// ─────────────────────────────────────────────────────────────────────────────
void setupWifi() {
    Serial.printf("[WiFi] Conectando a %s", WIFI_SSID);
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    WiFi.setAutoReconnect(true);

    // Espera bloqueante apenas no setup inicial (até 20s)
    unsigned long t = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t < 20000) {
        delay(500);
        Serial.print(".");
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.printf("\n[WiFi] Conectado. IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
        Serial.println("\n[WiFi] Timeout — continuando sem WiFi.");
    }
}

void ensureWifi() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[WiFi] Reconectando...");
        WiFi.disconnect();
        WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MQTT
// ─────────────────────────────────────────────────────────────────────────────
void setupMqtt() {
    mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
    mqttClient.setCallback(mqttCallback);
    mqttClient.setKeepAlive(30);
    mqttClient.setSocketTimeout(10);
    ensureMqtt();
}

void subscribeToInfo() {
    char infoTopic[80];
    snprintf(infoTopic, sizeof(infoTopic), "parquimetro/%s/info", METER_ID);
    mqttClient.subscribe(infoTopic);
    Serial.printf("[MQTT] Inscrito no topico: %s\n", infoTopic);
}

void ensureMqtt() {
    if (WiFi.status() != WL_CONNECTED) return;
    if (mqttClient.connected()) return;

    Serial.printf("[MQTT] Conectando a %s:%d...", MQTT_BROKER, MQTT_PORT);

    bool ok;
    if (strlen(MQTT_USER) > 0) {
        ok = mqttClient.connect(mqttClientId, MQTT_USER, MQTT_PASS);
    } else {
        ok = mqttClient.connect(mqttClientId);
    }

    if (ok) {
        Serial.println(" OK");
        subscribeToInfo();
        // Re-publicar estado atual após reconexão
        if (lastPublished != SpotState::UNKNOWN) {
            publishState(lastPublished);
        }
    } else {
        Serial.printf(" FALHOU (rc=%d)\n", mqttClient.state());
    }
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
    char msg[length + 1];
    memcpy(msg, payload, length);
    msg[length] = '\0';
    Serial.printf("[MQTT] Recebido [%s]: %s\n", topic, msg);

    // Payload esperado: info:RESTANTES:MODELO|PLACA|COR
    if (strstr(msg, "info:") == msg) {
        char* data = msg + 5;
        char* token = strtok(data, ":");
        if (token) remainingMinutes = atol(token);

        token = strtok(NULL, "|");
        if (token) strncpy(vehicleModel, token, sizeof(vehicleModel)-1);

        token = strtok(NULL, "|");
        if (token) strncpy(vehiclePlate, token, sizeof(vehiclePlate)-1);

        token = strtok(NULL, "|");
        if (token) strncpy(vehicleColor, token, sizeof(vehicleColor)-1);

        lastInfoReceivedMs = millis();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Sensor HC-SR04
// ─────────────────────────────────────────────────────────────────────────────
long readDistanceCm() {
    // Pulso de trigger
    digitalWrite(HCSR04_TRIG_PIN, LOW);
    delayMicroseconds(2);
    digitalWrite(HCSR04_TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(HCSR04_TRIG_PIN, LOW);

    long duration = pulseIn(HCSR04_ECHO_PIN, HIGH, ECHO_TIMEOUT_US);
    if (duration == 0) return -1; // timeout → sem objeto detectado

    long cm = duration / 58L;
    return cm;
}

// ─────────────────────────────────────────────────────────────────────────────
// Lógica de detecção de vaga
// ─────────────────────────────────────────────────────────────────────────────
void processDistance(long cm) {
    unsigned long now = millis();

    bool objectDetected = (cm > 0 && cm <= OCCUPIED_THRESHOLD_CM);

    if (objectDetected) {
        // Vaga ocupada — cancela timer de "livre"
        freeTimerRunning = false;
        freeStartMs = 0;

        if (currentState != SpotState::OCCUPIED) {
            currentState = SpotState::OCCUPIED;
            Serial.printf("[Sensor] Vaga OCUPADA (%.0ld cm)\n", cm);

            // Sempre gera um NOVO código quando muda de FREE para OCCUPIED
            long code = random(100000, 999999);
            snprintf(currentSessionCode, sizeof(currentSessionCode), "%06ld", code);
            sessionCodeGeneratedMs = now;

            // Limpa info do veículo anterior para garantir que a nova sessão comece limpa
            vehiclePlate[0] = '\0';
            vehicleModel[0] = '\0';
            vehicleColor[0] = '\0';
            remainingMinutes = 0;

            Serial.printf("[Sessao] Novo codigo gerado: %s\n", currentSessionCode);

            // Publica imediatamente a mudança
            publishState(SpotState::OCCUPIED, true);
        }

    } else {
        // Sem objeto detectado (Vaga livre)

        if (currentState != SpotState::FREE) {
            currentState = SpotState::FREE;
            Serial.println("[Sensor] Vaga LIVRE detectada");

            // Limpa TUDO da sessão anterior
            currentSessionCode[0] = '\0';
            sessionCodeGeneratedMs = 0;
            remainingMinutes = 0;
            vehiclePlate[0] = '\0';
            vehicleModel[0] = '\0';
            vehicleColor[0] = '\0';
            lastPublishedPayload[0] = '\0'; // Reseta cache de publicação

            // Publica imediatamente o estado LIVRE para encerrar sessão no backend
            publishState(SpotState::FREE, true);
        }

        freeTimerRunning = false;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Publicação MQTT — Otimizada para evitar envios redundantes
// ─────────────────────────────────────────────────────────────────────────────
void publishState(SpotState state, bool force) {
    if (!mqttClient.connected()) return;

    char payload[40];
    if (state == SpotState::OCCUPIED) {
        if (strlen(currentSessionCode) > 0) {
            snprintf(payload, sizeof(payload), "ocupado:%s", currentSessionCode);
        } else {
            strcpy(payload, "ocupado");
        }
    } else {
        strcpy(payload, "livre");
    }

    // Só publica se o payload mudou ou se for forçado
    if (!force && strcmp(payload, lastPublishedPayload) == 0) {
        return;
    }

    bool ok = mqttClient.publish(mqttTopic, payload, true); // retained = true

    if (ok) {
        lastPublished = state;
        lastPublishMs = millis();
        strncpy(lastPublishedPayload, payload, sizeof(lastPublishedPayload) - 1);
        Serial.printf("[MQTT] Publicado [%s]: %s\n", mqttTopic, payload);
    } else {
        Serial.println("[MQTT] Falha ao publicar");
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// OLED
// ─────────────────────────────────────────────────────────────────────────────
void setupOled() {
    oledOk = oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS);
    if (!oledOk) {
        Serial.println("[OLED] Display nao encontrado — continuando sem display");
        return;
    }
    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);
    oled.setTextSize(1);
    oled.setCursor(0, 0);
    oled.println("PontoLivre");
    oled.printf("Meter: %s\n", METER_ID);
    oled.printf("FW: %s\n", FW_VERSION);
    oled.display();
    Serial.println("[OLED] Display inicializado");
}

void updateOled(long cm) {
    if (!oledOk) return;

    oled.clearDisplay();
    oled.setTextSize(1);
    oled.setTextColor(SSD1306_WHITE);

    if (currentState == SpotState::FREE) {
        oled.setCursor(0, 0);
        oled.println("PontoLivre");
        oled.printf("Vaga: %s\n", METER_ID);
        oled.setCursor(0, 32);
        oled.setTextSize(2);
        oled.print("LIVRE");
        oled.display();
        return;
    }

    if (currentState == SpotState::OCCUPIED) {
        // Lógica de intercalar telas
        static int displayMode = 0;
        static unsigned long lastSwitchMs = 0;
        if (millis() - lastSwitchMs >= 3000) {
            displayMode = (displayMode + 1) % 4; // Aumentado para 4 modos
            lastSwitchMs = millis();
        }

        // 1. Caso seja um carro que não iniciou sessão (vaga ocupada mas sem placa/veículo)
        if (strlen(vehiclePlate) == 0) {
            switch(displayMode % 3) { // Ciclo menor para vaga não paga
                case 0:
                    oled.setTextSize(2);
                    oled.setCursor(0, 10);
                    oled.print("OCUPADA");
                    break;
                case 1:
                    oled.setCursor(0, 16);
                    oled.setTextSize(2);
                    oled.print("NAO PAGA");
                    break;
                case 2:
                    oled.setCursor(0, 0);
                    oled.println("ALERTA:");
                    oled.setCursor(0, 24);
                    oled.setTextSize(1);
                    oled.println("PASSIVEL DE MULTA");
                    if (strlen(currentSessionCode) > 0) {
                        oled.setCursor(0, 48);
                        oled.printf("COD: %s", currentSessionCode);
                    }
                    break;
            }
        } else {
            // 2. Sessão Ativa com veículo - Intercalando

            // Se remainingMinutes > 0, significa que o usuário PAGOU pelo menos 1h e ainda tem tempo.
            bool estaPago = (remainingMinutes > 0);

            switch(displayMode) {
                case 0: // Status / Pago
                    oled.setTextSize(2);
                    oled.setCursor(0, 10);
                    oled.print("OCUPADA");
                    oled.setTextSize(1);
                    oled.setCursor(0, 40);
                    oled.print(estaPago ? "PAGO (SESSAO OK)" : "AGUARD. PAGAMENTO");
                    break;
                case 1: // Tempo Restante
                    oled.setCursor(0, 0);
                    oled.print(estaPago ? "TEMPO RESTANTE" : "LIMITE EXCEDIDO");
                    oled.setCursor(0, 24);
                    oled.setTextSize(2);
                    if (!estaPago) {
                        oled.print("MULTA!");
                    } else {
                        oled.printf("%ld min", remainingMinutes);
                    }
                    break;
                case 2: // Veículo
                    oled.setCursor(0, 0);
                    oled.print("VEICULO:");
                    oled.setCursor(0, 16);
                    oled.printf("Mod: %s", vehicleModel);
                    oled.setCursor(0, 32);
                    oled.printf("Placa: %s", vehiclePlate);
                    oled.setCursor(0, 48);
                    oled.printf("Cor: %s", vehicleColor);
                    break;
                case 3: // Informação de "PAGO" em destaque
                    oled.setTextSize(2);
                    oled.setCursor(0, 20);
                    if (!estaPago) {
                        oled.print("NAO PAGA!");
                    } else {
                        oled.print(" STATUS: ");
                        oled.setCursor(0, 40);
                        oled.print("  PAGO");
                    }
                    break;
            }
        }
    } else {
        // Estado UNKNOWN ou Confirmando...
        oled.setCursor(0, 0);
        oled.printf("Meter: %s", METER_ID);
        if (freeTimerRunning) {
            unsigned long elapsed = (millis() - freeStartMs) / 1000;
            oled.setCursor(0, 40);
            oled.printf("Confirmando...\n%lus/%lus", elapsed, FREE_CONFIRM_MS / 1000);
        } else {
            oled.setCursor(0, 40);
            oled.print("Sincronizando...");
        }
    }

    oled.display();
}
