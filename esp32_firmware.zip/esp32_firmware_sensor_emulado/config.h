#pragma once

// ── WiFi ──────────────────────────────────────────────────────────────────────
#define WIFI_SSID       "SeuWiFi"
#define WIFI_PASSWORD   "SuaSenha"

// ── MQTT ──────────────────────────────────────────────────────────────────────
// IP do computador rodando Mosquitto na mesma rede
#define MQTT_BROKER     "192.168.200.45"
#define MQTT_PORT       1883
#define MQTT_USER       ""
#define MQTT_PASS       ""

// ID único deste parquímetro — deve corresponder ao `code` no banco de dados
#define METER_ID        "PKM-001"

// Tópico publicado: parquimetro/<METER_ID>/status
// Payloads: "Ocupado" | "Livre"

// ── Simulador de Vaga ─────────────────────────────────────────────────────────
#define SIMULATOR_PIN       18  // Conectar ao GND para simular vaga ocupada

// ── OLED SSD1306 (I2C) ────────────────────────────────────────────────────────
#define OLED_SDA_PIN        21
#define OLED_SCL_PIN        22
#define OLED_ADDRESS        0x3C
#define OLED_WIDTH          128
#define OLED_HEIGHT         64

// ── Temporização ──────────────────────────────────────────────────────────────
// Tempo contínuo vazio antes de publicar "Livre" (ms)
#define FREE_CONFIRM_MS         2000UL    // 2 segundos para teste rápido

// Intervalo mínimo entre publicações do mesmo status (ms)
#define PUBLISH_DEBOUNCE_MS     1000UL    // 1 segundo

// Intervalo de leitura do sensor (ms)
#define SENSOR_READ_INTERVAL_MS 200UL

// Intervalo de verificação de conexão (ms)
#define CONN_CHECK_INTERVAL_MS  5000UL

// ── Versão do firmware ────────────────────────────────────────────────────────
#define FW_VERSION  "1.0.1-SIM"